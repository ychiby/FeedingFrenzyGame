package application;

import javafx.application.Application;

public class Boot {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Application.launch(WelcomePage.class);

	}

}
