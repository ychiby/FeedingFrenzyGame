package application;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import java.util.Random;

public class SmallFish extends Fish {
    private static final String[] IMAGE_PATHS = {
        "/images/SmallFishimages/fishIcon0.png",
        "/images/SmallFishimages/fishIcon1.png",
        "/images/SmallFishimages/fishIcon2.png",
        "/images/SmallFishimages/fishIcon3.png",
        "/images/SmallFishimages/fishIcon4.png",
        "/images/SmallFishimages/fishIcon5.png",
        "/images/SmallFishimages/fishIcon7.png",
        "/images/SmallFishimages/fishIcon8.png",
        "/images/SmallFishimages/fishIcon9.png",
        "/images/SmallFishimages/fishIcon10.png",
        "/images/SmallFishimages/fishIcon12.png",
        "/images/SmallFishimages/fishIconL12.png",
        "/images/SmallFishimages/fishIcon13.png",
        "/images/SmallFishimages/fishIcon14.png",
        "/images/SmallFishimages/fishIcon16.png"
    };

    public SmallFish() {
        super(getRandomImage(), 40, 10); // Size and points for small fish
        this.speed = 0.5 + new Random().nextDouble(); // Speed between 0.5 and 1.5
        this.getImageView().setFitWidth(40);
        this.getImageView().setFitHeight(40);
    }

    private static String getRandomImage() {
        return IMAGE_PATHS[new Random().nextInt(IMAGE_PATHS.length)];
    }

    @Override
    public void move() {
        // Move the fish based on its speed and direction
        setX(getX() + getDirectionX() * speed);
        setY(getY() + getDirectionY() * speed);

        // Check for screen boundaries and wrap around
        if (getX() > 1180) setX(-getFitWidth());
        if (getX() < -getFitWidth()) setX(1180);
        if (getY() > 640) setY(-getFitHeight());
        if (getY() < -getFitHeight()) setY(640);
    }

    private double getDirectionX() {
        // Implement your logic for horizontal direction
        return 1; // Example: move right
    }

    private double getDirectionY() {
        // Implement your logic for vertical direction
        return 0; // Example: no vertical movement
    }

    public double getFitWidth() {
        return getImageView().getFitWidth();
    }

    public double getFitHeight() {
        return getImageView().getFitHeight();
    }

    public void setX(double x) {
        getImageView().setX(x);
    }

    public void setY(double y) {
        getImageView().setY(y);
    }
}