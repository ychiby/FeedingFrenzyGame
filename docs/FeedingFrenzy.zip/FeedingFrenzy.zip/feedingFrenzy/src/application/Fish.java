package application;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Fish {
    protected ImageView imageView;
    protected double size;
    protected double speed;
    protected int points;

    public Fish(String imagePath, double size, int points) {
        Image image = loadImage(imagePath);
        if (image == null) {
            throw new IllegalArgumentException("Image not found: " + imagePath);
        }
        imageView = new ImageView(image);
        imageView.setFitWidth(size);
        imageView.setFitHeight(size);
        this.size = size;
        this.points = points;
        speed = 0.5 + new java.util.Random().nextDouble() * 0.5; // Default speed
    }

    private Image loadImage(String imagePath) {
        Image image = new Image(getClass().getResourceAsStream(imagePath));
        if (image == null) {
            System.err.println("Error loading image: " + imagePath);
        }
        return image;
    }

    public ImageView getImageView() {
        return imageView;
    }

    public double getX() {
        return imageView.getX();
    }

    public double getY() {
        return imageView.getY();
    }

    public double getWidth() {
        return imageView.getFitWidth();
    }

    public double getHeight() {
        return imageView.getFitHeight();
    }

    public double getSize() {
        return size;
    }

    public int getPoints() {
        return points;
    }

    public void move() {
        imageView.setX(imageView.getX() + speed);
    }
}