package application;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;
import javafx.geometry.Pos;
import javafx.scene.text.Font;
import java.net.URL;

public class WelcomePage extends Application {

    @Override
    public void start(Stage primaryStage) {
        // Load background image
        URL imageURL = getClass().getResource("/ui/background.gif");
        if (imageURL == null) {
            throw new RuntimeException("Missing: /ui/background.gif");
        }
        ImageView background = new ImageView(new Image(imageURL.toExternalForm()));
        background.setPreserveRatio(false);
        background.fitWidthProperty().bind(primaryStage.widthProperty());
        background.fitHeightProperty().bind(primaryStage.heightProperty());

        // Load and play background music
        URL soundURL = getClass().getResource("/sound/intro.mp3");
        if (soundURL == null) {
            throw new RuntimeException("Missing: /sound/intro.mp3");
        }
        MediaPlayer mediaPlayer = new MediaPlayer(new Media(soundURL.toExternalForm()));
        mediaPlayer.setCycleCount(MediaPlayer.INDEFINITE);
        mediaPlayer.play();

        // Create start button
        Button startButton = new Button("Start Game");
        startButton.setFont(Font.font(18));

        startButton.setOnAction(e -> {
            mediaPlayer.stop();
            new GameControl(primaryStage); // Switch to game scene
        });

        // Create menu with only the start button
        VBox menu = new VBox(20, startButton);
        menu.setAlignment(Pos.CENTER);

        StackPane root = new StackPane(background, menu);
        Scene scene = new Scene(root, 800, 600);

        primaryStage.setTitle("Feeding Frenzy - Welcome");
        primaryStage.setScene(scene);
        primaryStage.setResizable(true);
        primaryStage.show();

        // Handle full-screen mode
        primaryStage.fullScreenProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue) {
                scene.setRoot(root);
            }
        });
    }

    public static void main(String[] args) {
        launch(args);
    }
}