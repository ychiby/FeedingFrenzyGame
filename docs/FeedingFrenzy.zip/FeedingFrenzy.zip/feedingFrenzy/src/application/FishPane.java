package application;

import javafx.animation.AnimationTimer;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.effect.ColorAdjust;
import javafx.scene.effect.Glow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.media.AudioClip;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class FishPane extends Pane {
    public Player player;
    private List<EnemyFish> enemyFishes = new ArrayList<>();
    private Random random = new Random();
    private AudioClip eatSound;
    private AudioClip hurtSound;
    private AudioClip failureSound;
    private AudioClip victorySound;
    
    // Game constants
    private static final int INITIAL_TIME = 60;
    private int targetScore = 300;
    private static final int MAX_ENEMIES = 15;
    private static final double PLAYER_SIZE = 160;
    private static final Font UI_FONT = Font.font("Arial", FontWeight.BOLD, 24);
    private static final Color UI_COLOR = Color.WHITE;
    private static final Color SUCCESS_COLOR = Color.LIMEGREEN;
    private static final Color FAILURE_COLOR = Color.INDIANRED;
    private double bigFishProbability = 0.2;
    private int level = 1;

    // Game state
    private AnimationTimer gameLoop;
    private Timeline countdownTimer;
    private int score = 0;
    private int remainingTime = INITIAL_TIME;
    private int highScore = 0;
    private boolean gameCompleted = false;
    
    // UI elements
    private Text scoreText, timeText, targetText, highScoreText;

    public FishPane() {
        loadHighScore();
        initializeSounds();
        initializeGame();
    }

    private void initializeSounds() {
        try {
            eatSound = new AudioClip(getClass().getResource("/sound/tralalero-tralala-meme_R8mqoQo.mp3").toString());
            eatSound.setVolume(0.7);
            
            hurtSound = new AudioClip(getClass().getResource("/sound/hurt.mp3").toString());
            hurtSound.setVolume(0.7);
            System.out.println("Hurt sound loaded: " + (hurtSound != null));
            
            failureSound = new AudioClip(getClass().getResource("/sound/gta-v-death-sound-effect-102.mp3").toString());
            failureSound.setVolume(0.7);
            
            victorySound = new AudioClip(getClass().getResource("/sound/victory-mario-series-hq-super-smash-bros.mp3").toString());
            victorySound.setVolume(0.7);
        } catch (Exception e) {
            System.err.println("Error loading sound effects: " + e.getMessage());
        }
    }

    private void initializeGame() {
        initializePlayer();
        initializeUI();
        createInitialEnemies();
        startGameLoop();
        startCountdown();
    }

    private void initializePlayer() {
        player = new Player("/images/fishRight.png", "/images/fishLeft.png");
        player.setFitWidth(PLAYER_SIZE);
        player.setFitHeight(PLAYER_SIZE / 2);
        player.setX(200);
        player.setY(300);
        getChildren().add(player);
    }

    private void initializeUI() {
        scoreText = createUIText(20, 40, "Score: 0");
        timeText = createUIText(20, 80, "Time: " + remainingTime);
        targetText = createUIText(20, 120, "Target: " + targetScore);
        highScoreText = createUIText(20, 160, "Record: " + highScore);
        highScoreText.setFill(Color.GOLD);
    }

    private Text createUIText(double x, double y, String content) {
        Text text = new Text(x, y, content);
        text.setFont(UI_FONT);
        text.setFill(UI_COLOR);
        text.setEffect(new javafx.scene.effect.DropShadow(5, Color.BLACK));
        getChildren().add(text);
        return text;
    }

    private void loadHighScore() {
        File file = new File("highscore.dat");
        if (file.exists()) {
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                String line = reader.readLine();
                if (line != null && !line.isEmpty()) {
                    highScore = Integer.parseInt(line);
                }
            } catch (Exception e) {
                System.err.println("Error loading high score: " + e.getMessage());
            }
        }
    }

    private void saveHighScore() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("highscore.dat"))) {
            writer.write(Integer.toString(highScore));
        } catch (IOException e) {
            System.err.println("Error saving high score: " + e.getMessage());
        }
    }

    private void updateHighScore() {
        if (score > highScore) {
            highScore = score;
            highScoreText.setText("Record: " + highScore);
            saveHighScore();
        }
    }

    private void resetGame(boolean increaseDifficulty) {
        if (increaseDifficulty) {
            level++;
            if (level == 2) {
                targetScore = 1000;
            } else if (level > 2) {
                targetScore += 200;
            }
            
            bigFishProbability = Math.min(0.2 + (level - 1) * 0.05, 0.5);
            targetText.setText("Target: " + targetScore);
        }
        
        updateHighScore();
        enemyFishes.forEach(fish -> getChildren().remove(fish.getImageView()));
        enemyFishes.clear();
        
        score = 0;
        remainingTime = INITIAL_TIME;
        gameCompleted = false;
        
        scoreText.setText("Score: 0");
        timeText.setText("Time: " + remainingTime);
        timeText.setFill(UI_COLOR);
        
        createInitialEnemies();
        player.setX(200);
        player.setY(300);
        
        startGameLoop();
        startCountdown();
    }

    private void createInitialEnemies() {
        for (int i = 0; i < MAX_ENEMIES; i++) {
            spawnEnemyFish();
        }
    }

    private void spawnEnemyFish() {
        FishType type = getRandomFishType();
        double size = calculateFishSize(type);
        
        EnemyFish fish = new EnemyFish(type.imagePath, size, type.points);
        positionFish(fish);
        
        getChildren().add(fish.getImageView());
        enemyFishes.add(fish);
    }

    private FishType getRandomFishType() {
        return random.nextDouble() < bigFishProbability
            ? FishType.values()[random.nextInt(2) + 4]
            : FishType.values()[random.nextInt(4)];
    }

    private double calculateFishSize(FishType type) {
        double size = type.minSize + random.nextDouble() * (type.maxSize - type.minSize);
        return Math.min(size, PLAYER_SIZE / 4);
    }

    private void positionFish(EnemyFish fish) {
        fish.getImageView().setX(-fish.getWidth());
        fish.getImageView().setY(random.nextDouble() * (600 - fish.getHeight()));
    }

    private void startGameLoop() {
        if (gameLoop != null) gameLoop.stop();
        
        gameLoop = new AnimationTimer() {
            @Override
            public void handle(long now) {
                if (!gameCompleted) {
                    updateEnemies();
                    checkCollisions();
                }
            }
        };
        gameLoop.start();
    }

    private void updateEnemies() {
        enemyFishes.forEach(EnemyFish::move);
        
        enemyFishes.removeIf(fish -> {
            if (fish.getX() > getWidth() || fish.getX() < -fish.getWidth()) {
                getChildren().remove(fish.getImageView());
                return true;
            }
            return false;
        });
        
        while (enemyFishes.size() < MAX_ENEMIES) {
            spawnEnemyFish();
        }
    }

    private void checkCollisions() {
        enemyFishes.removeIf(fish -> {
            if (player.getBoundsInParent().intersects(fish.getImageView().getBoundsInParent())) {
                handleCollision(fish);
                getChildren().remove(fish.getImageView());
                return true;
            }
            return false;
        });
    }

    private void handleCollision(EnemyFish fish) {
        boolean playerIsBigger = player.getFitWidth() > fish.getSize() * 1.3;
        int pointsChange = playerIsBigger ? fish.getPoints() : -fish.getPoints();
        score = Math.max(score + pointsChange, 0);
        scoreText.setText("Score: " + score);
        
        if (playerIsBigger) {
            if (fish.getPoints() > 0 && eatSound != null) {
                eatSound.play();
            }
        }
        
        // Play hurt sound when:
        // 1. Enemy is bigger, OR
        // 2. Enemy has negative points (dangerous fish)
        if ((!playerIsBigger || fish.getPoints() < 0) && hurtSound != null) {
            System.out.println("Playing hurt sound - Player bigger: " + playerIsBigger + ", Fish points: " + fish.getPoints());
            hurtSound.play();
        }
    }

    private void startCountdown() {
        if (countdownTimer != null) countdownTimer.stop();
        
        timeText.setFill(UI_COLOR);
        countdownTimer = new Timeline(new KeyFrame(Duration.seconds(1), event -> {
            remainingTime--;
            timeText.setText("Time: " + remainingTime);
            
            if (remainingTime <= 10) {
                timeText.setFill(Color.ORANGERED);
            }
            
            if (remainingTime <= 0) {
                gameCompleted = true;
                countdownTimer.stop();
                checkGameResult();
            }
        }));
        countdownTimer.setCycleCount(INITIAL_TIME);
        countdownTimer.play();
    }

    private void checkGameResult() {
        gameLoop.stop();
        updateHighScore();
        
        boolean targetReached = score >= targetScore;
        
        if (targetReached && victorySound != null) {
            victorySound.play();
        } else if (!targetReached && failureSound != null) {
            failureSound.play();
        }
        
        Platform.runLater(() -> {
            showGameResultPopup(
                targetReached ? "LEVEL COMPLETE!" : "GAME OVER", 
                targetReached ? "You reached the target score!" : "Time's up! Try again!", 
                targetReached ? SUCCESS_COLOR : FAILURE_COLOR,
                targetReached
            );
        });
    }

    private void showGameResultPopup(String title, String message, Color color, boolean targetReached) {
        Stage popupStage = new Stage();
        popupStage.initModality(Modality.APPLICATION_MODAL);
        popupStage.initStyle(StageStyle.UTILITY);
        popupStage.setTitle(title);
        popupStage.setResizable(false);

        VBox layout = new VBox(15);
        layout.setAlignment(Pos.CENTER);
        layout.setStyle("-fx-background-color: #2F343F; -fx-padding: 30; -fx-border-color: #575757; -fx-border-width: 2;");
        
        Label titleLabel = new Label(title);
        titleLabel.setFont(Font.font("Arial", FontWeight.BOLD, 28));
        titleLabel.setTextFill(color);
        
        Label messageLabel = new Label(message);
        messageLabel.setFont(Font.font(18));
        messageLabel.setTextFill(Color.WHITE);
        messageLabel.setAlignment(Pos.CENTER);
        
        Label scoreLabel = new Label("Your Score: " + score);
        scoreLabel.setFont(Font.font(20));
        scoreLabel.setTextFill(Color.WHITE);
        
        Label highScoreLabel = new Label("High Score: " + highScore);
        highScoreLabel.setFont(Font.font(20));
        highScoreLabel.setTextFill(Color.GOLD);
        
        String buttonText = targetReached ? "NEXT LEVEL" : "PLAY AGAIN";
        Button actionButton = new Button(buttonText);
        actionButton.setStyle("-fx-font-size: 18; -fx-padding: 10 25; -fx-background-color: #4CAF50; -fx-text-fill: white;");
        actionButton.setOnAction(e -> {
            popupStage.close();
            resetGame(targetReached);
        });

        layout.getChildren().addAll(
            titleLabel, 
            messageLabel, 
            new Separator(), 
            scoreLabel, 
            highScoreLabel, 
            actionButton
        );

        Scene scene = new Scene(layout);
        popupStage.setScene(scene);
        popupStage.sizeToScene();
        popupStage.showAndWait();
    }

    private class EnemyFish {
        private ImageView imageView;
        private double size;
        private double speed;
        private int points;

        public EnemyFish(String imagePath, double size, int points) {
            this.size = size;
            this.points = points;
            try {
                imageView = new ImageView(new Image(getClass().getResourceAsStream(imagePath)));
                imageView.setFitWidth(size);
                imageView.setFitHeight(size);
                ensureCorrectOrientation();
                
                if (points < 0) {
                    ColorAdjust redTint = new ColorAdjust();
                    redTint.setHue(0.05);
                    redTint.setSaturation(0.7);
                    
                    Glow glow = new Glow(0.5);
                    glow.setInput(redTint);
                    
                    imageView.setEffect(glow);
                    imageView.setStyle("-fx-effect: dropshadow(three-pass-box, rgba(255,0,0,0.7), 8, 0.5, 0, 0);");
                }
            } catch (Exception e) {
                System.err.println("Error loading fish image: " + imagePath);
                throw new RuntimeException("Missing fish image: " + imagePath);
            }

            speed = imagePath.contains("BigFishimages") 
                ? 2 + random.nextDouble() * 2
                : 0.5 + random.nextDouble();
        }

        private void ensureCorrectOrientation() {
            imageView.setRotate(180);
            imageView.setScaleY(-1);
        }

        public void move() {
            imageView.setX(imageView.getX() + speed);
        }

        public ImageView getImageView() { return imageView; }
        public double getX() { return imageView.getX(); }
        public double getY() { return imageView.getY(); }
        public double getWidth() { return imageView.getFitWidth(); }
        public double getHeight() { return imageView.getFitHeight(); }
        public double getSize() { return size; }
        public int getPoints() { return points; }
    }

    private enum FishType {
        SMALL("/SmallFishimages/fishIcon0.png", 37.5, 37.5, 10),
        SMALL_R("/SmallFishimages/fishIcon1.png", 37.5, 37.5, 5),
        MEDIUM("/SmallFishimages/fishIcon2.png", 75, 75, 25),
        MEDIUM_R("/SmallFishimages/fishIcon3.png", 75, 75, 40),
        LARGE("/BigFishimages/fishIconL1.png", 90, 90, -70),
        LARGE_R("/BigFishimages/fishIconL10.png", 90, 90, -50);

        final String imagePath;
        final double minSize, maxSize;
        final int points;

        FishType(String path, double min, double max, int points) {
            this.imagePath = path;
            this.minSize = min;
            this.maxSize = max;
            this.points = points;
        }
    }
}