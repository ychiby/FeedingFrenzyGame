package application;

import java.util.Random;

public class BigFish extends Fish {
    private static final String[] IMAGE_PATHS = {
        "/BigFishimages/fishIconL1.png",
        "/BigFishimages/fishIconL10.png",
        "/BigFishimages/fishIconL11.png",
        "/BigFishimages/fishIconL13.png",
        "/BigFishimages/fishIconL14.png",
        "/BigFishimages/fishIconL15.png",
        "/BigFishimages/fishIconL16.png",
        "/BigFishimages/fishIconL17.png",
        "/BigFishimages/fishIconL18.png",
        "/BigFishimages/shop-13.png",
        "/BigFishimages/small.png",
        "/BigFishimages/small2r.png",
        "/BigFishimages/wujin_17.png",
        "/BigFishimages/wujin_17right.png"
    };

    public BigFish(double size, int points) {
        super(getRandomImage(), size, points);
        this.speed = 1 + new Random().nextDouble() * 2; // Speed between 1 and 3
    }

    private static String getRandomImage() {
        return IMAGE_PATHS[new Random().nextInt(IMAGE_PATHS.length)];
    }

    @Override
    public double getWidth() {
        return super.getWidth();
    }

    @Override
    public double getHeight() {
        return super.getHeight();
    }

    @Override
    public void move() {
        // Move the fish based on its speed and direction
        double newX = getX() + getDirectionX() * speed;
        double newY = getY() + getDirectionY() * speed;

        // Check for screen boundaries and wrap around
        if (newX > 1180) newX = -getWidth();
        if (newX < -getWidth()) newX = 1180;
        if (newY > 640) newY = -getHeight();
        if (newY < -getHeight()) newY = 640;

        setX(newX);
        setY(newY);
    }

    private double getDirectionX() {
        // Implement your logic for horizontal direction
        return 1; // Example: move right
    }

    private double getDirectionY() {
        // Implement your logic for vertical direction
        return 0; // Example: no vertical movement
    }

    public void setX(double x) {
        getImageView().setX(x);
    }

    public void setY(double y) {
        getImageView().setY(y);
    }
}