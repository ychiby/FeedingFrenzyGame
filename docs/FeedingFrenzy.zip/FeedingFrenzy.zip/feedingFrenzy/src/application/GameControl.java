package application;

import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class GameControl {
    public GameControl(Stage primaryStage) {
        // Create game pane
        FishPane gamePane = new FishPane();
        
        // Setup root container with background
        StackPane root = new StackPane();
        
        // Add background image if needed (original implementation)
        try {
            ImageView background = new ImageView(new Image(getClass().getResourceAsStream("/images/background1.jpg")));
            background.setPreserveRatio(false);
            background.fitWidthProperty().bind(primaryStage.widthProperty());
            background.fitHeightProperty().bind(primaryStage.heightProperty());
            root.getChildren().add(background);
        } catch (Exception e) {
            System.err.println("Couldn't load background image: " + e.getMessage());
        }
        
        root.getChildren().add(gamePane);
        
        // Create scene
        Scene scene = new Scene(root, 800, 600);
        
        // Handle keyboard input
        scene.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.LEFT) {
                gamePane.player.moveLeft();
            } else if (e.getCode() == KeyCode.RIGHT) {
                gamePane.player.moveRight();
            } else if (e.getCode() == KeyCode.UP) {
                gamePane.player.moveUp();
            } else if (e.getCode() == KeyCode.DOWN) {
                gamePane.player.moveDown();
            } else if (e.getCode() == KeyCode.F11) {
                primaryStage.setFullScreen(!primaryStage.isFullScreen());
            }
        });
        
        // Configure stage
        primaryStage.setTitle("Feeding Frenzy");
        primaryStage.setScene(scene);
        primaryStage.setResizable(true);  // Changed back to true for fullscreen
        primaryStage.setFullScreenExitHint("Press F11 to exit fullscreen");
        primaryStage.show();
        
        // Request focus for key events
        gamePane.requestFocus();
    }
}