package application;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Player extends ImageView {
    private Image leftImage;
    private Image rightImage;

    public Player(String rightImagePath, String leftImagePath) {
        // Load player images from resources
        rightImage = new Image(getClass().getResourceAsStream(rightImagePath));
        leftImage = new Image(getClass().getResourceAsStream(leftImagePath));

        this.setImage(rightImage);

        // Set size (you can adjust)
        this.setFitWidth(160);
        this.setFitHeight(80);

        // Initial position
        this.setX(200);
        this.setY(300);
    }

    public void moveUp() {
        this.setY(this.getY() - 10);
    }

    public void moveDown() {
        this.setY(this.getY() + 10);
    }

    public void moveLeft() {
        this.setX(this.getX() - 10);
        this.setImage(leftImage);
    }

    public void moveRight() {
        this.setX(this.getX() + 10);
        this.setImage(rightImage);
    }
}