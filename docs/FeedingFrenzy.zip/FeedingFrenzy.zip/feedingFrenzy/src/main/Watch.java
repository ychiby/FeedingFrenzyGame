package main;

public class Watch {
private long endTime;
private long startTime;
public Watch () { 
	
}
public long getstartTime() {
	return startTime;
}
public long getendTime() {
	return endTime;
}
	public static void main(String[] args) {

	}

}
