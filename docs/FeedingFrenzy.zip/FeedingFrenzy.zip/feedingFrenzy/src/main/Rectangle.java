package main;

public class Rectangle {
    private double width = 4.0, height = 3.0;

    public double getWidth() { return width; }
    public double getHeight() { return height; }
    public double getArea() { return width * height; }
    public double getPerimeter() { return 2 * (width + height); }

    public static void main(String[] args) {
        Rectangle rect = new Rectangle();
        System.out.println("Width: " + rect.getWidth());
    }
}
